const config = {
  app: {
    port: 8080
  },
  db: {
    host: 'localhost',
    port: 3306,
    database: 'phpmyadmin',
    user: 'phpmyadmin',
    password: 'root'
  },
  gmail: {
    user: 'bobocheck2006@gmail.com',
    mdp: '...'
  }
};


module.exports = config;

