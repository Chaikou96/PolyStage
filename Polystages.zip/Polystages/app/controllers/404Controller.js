controllers.controller('404Controller', function ($scope, $rootScope) {
  $scope.titre = "404"

  $rootScope.checkConnexion()
})